package com.mycompany.prog6112_assignment_2;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class PROG6112_ASSIGNMENT_2 {

    public static void main(String[] args) {
        RescueOperationsSystem.main(args);
    }

    // INTERFACE - demonstrates interface-based design
   
    public interface RescueOperations {
        void startRescue();
        void completeRescue();
        String generateSummary();
    }

   
    // ABSTRACT BASE CLASS - abstraction + encapsulation

    public static abstract class RescueCase implements RescueOperations {

        // ---------- encapsulated fields ----------
        private String rescueCaseId;
        private String animalName;
        private String species;
        private String rescueLocation;
        private String assignedRanger;
        private int numberOfRescueDays;
        private double dailyCareCost;
        private String currentRescueStatus;

        // ---------- constructor ----------
        public RescueCase(String rescueCaseId, String animalName, String species,
                          String rescueLocation, String assignedRanger,
                          int numberOfRescueDays, double dailyCareCost,
                          String currentRescueStatus) {
            this.rescueCaseId = rescueCaseId;
            this.animalName = animalName;
            this.species = species;
            this.rescueLocation = rescueLocation;
            this.assignedRanger = assignedRanger;
            this.numberOfRescueDays = numberOfRescueDays;
            this.dailyCareCost = dailyCareCost;
            this.currentRescueStatus = currentRescueStatus;
        }

        // ---------- getters / setters ----------
        public String getRescueCaseId() { return rescueCaseId; }
        public void setRescueCaseId(String v) { this.rescueCaseId = v; }

        public String getAnimalName() { return animalName; }
        public void setAnimalName(String v) { this.animalName = v; }

        public String getSpecies() { return species; }
        public void setSpecies(String v) { this.species = v; }

        public String getRescueLocation() { return rescueLocation; }
        public void setRescueLocation(String v) { this.rescueLocation = v; }

        public String getAssignedRanger() { return assignedRanger; }
        public void setAssignedRanger(String v) { this.assignedRanger = v; }

        public int getNumberOfRescueDays() { return numberOfRescueDays; }
        public void setNumberOfRescueDays(int v) { this.numberOfRescueDays = v; }

        public double getDailyCareCost() { return dailyCareCost; }
        public void setDailyCareCost(double v) { this.dailyCareCost = v; }

        public String getCurrentRescueStatus() { return currentRescueStatus; }
        public void setCurrentRescueStatus(String v) { this.currentRescueStatus = v; }

        // ---------- abstract methods (implemented by subclasses) ----------
        public abstract double calculateTotalCost();
        public abstract String determinePriority();
        public abstract String getRescueType();
        public abstract String displaySpecificInfo();

        // ---------- shared helper: base cost ----------
        protected double calculateBaseCost() {
            return numberOfRescueDays * dailyCareCost;
        }

        // ---------- money formatter (Rands with space thousands separator) ----------
        public static String formatMoney(double amount) {
            DecimalFormat df = new DecimalFormat("#,##0.00");
            return "R" + df.format(amount).replace(",", " ");
        }
    }

   
    // SUBCLASS 1 - Injured Animal Rescue
  
    
    public static class InjuredAnimalRescue extends RescueCase {

        private String injuryDescription;
        private double veterinaryTreatmentCost;
        private boolean surgeryRequired;

        public InjuredAnimalRescue(String id, String name, String species,
                                   String location, String ranger,
                                   int days, double dailyCost, String status,
                                   String injuryDescription, double vetCost,
                                   boolean surgeryRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.injuryDescription = injuryDescription;
            this.veterinaryTreatmentCost = vetCost;
            this.surgeryRequired = surgeryRequired;
        }

        public String getInjuryDescription() { return injuryDescription; }
        public void setInjuryDescription(String v) { this.injuryDescription = v; }

        public double getVeterinaryTreatmentCost() { return veterinaryTreatmentCost; }
        public void setVeterinaryTreatmentCost(double v) { this.veterinaryTreatmentCost = v; }

        public boolean isSurgeryRequired() { return surgeryRequired; }
        public void setSurgeryRequired(boolean v) { this.surgeryRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = calculateBaseCost() + veterinaryTreatmentCost;
            if (surgeryRequired) total += 5000.00;
            return total;
        }

        @Override
        public String determinePriority() {
            if (surgeryRequired && veterinaryTreatmentCost > 10000) return "Critical";
            if (surgeryRequired || veterinaryTreatmentCost > 10000) return "High";
            if (veterinaryTreatmentCost > 3000) return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Injured Animal Rescue"; }

        @Override
        public String displaySpecificInfo() {
            return "Injury Description       : " + injuryDescription + "\n" +
                   "Veterinary Treatment Cost: " + formatMoney(veterinaryTreatmentCost) + "\n" +
                   "Surgery Required         : " + (surgeryRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus("Rescue in Progress"); }
        @Override public void completeRescue() { setCurrentRescueStatus("Rescue Completed"); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID   : " + getRescueCaseId() + "\n" +
                   "Rescue Type      : " + getRescueType() + "\n" +
                   "Species          : " + getSpecies() + "\n" +
                   "Assigned Ranger  : " + getAssignedRanger() + "\n" +
                   "Rescue Priority  : " + determinePriority() + "\n" +
                   "Current Status   : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost: " + formatMoney(calculateTotalCost());
        }
    }

    
    // SUBCLASS 2 - Orphaned Animal Rescue

    public static class OrphanedAnimalRescue extends RescueCase {

        private int estimatedAgeMonths;
        private double feedingCost;
        private boolean fosterCareRequired;

        public OrphanedAnimalRescue(String id, String name, String species,
                                    String location, String ranger,
                                    int days, double dailyCost, String status,
                                    int ageMonths, double feedingCost,
                                    boolean fosterCareRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.estimatedAgeMonths = ageMonths;
            this.feedingCost = feedingCost;
            this.fosterCareRequired = fosterCareRequired;
        }

        public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
        public void setEstimatedAgeMonths(int v) { this.estimatedAgeMonths = v; }

        public double getFeedingCost() { return feedingCost; }
        public void setFeedingCost(double v) { this.feedingCost = v; }

        public boolean isFosterCareRequired() { return fosterCareRequired; }
        public void setFosterCareRequired(boolean v) { this.fosterCareRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = calculateBaseCost() + feedingCost;
            if (fosterCareRequired) total += 2500.00;
            return total;
        }

        @Override
        public String determinePriority() {
            if (estimatedAgeMonths < 3 && fosterCareRequired) return "Critical";
            if (estimatedAgeMonths < 3 || fosterCareRequired) return "High";
            if (estimatedAgeMonths < 12) return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Orphaned Animal Rescue"; }

        @Override
        public String displaySpecificInfo() {
            return "Estimated Age (Months)   : " + estimatedAgeMonths + "\n" +
                   "Feeding Cost             : " + formatMoney(feedingCost) + "\n" +
                   "Foster Care Required     : " + (fosterCareRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus("Rescue in Progress"); }
        @Override public void completeRescue() { setCurrentRescueStatus("Rescue Completed"); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID   : " + getRescueCaseId() + "\n" +
                   "Rescue Type      : " + getRescueType() + "\n" +
                   "Species          : " + getSpecies() + "\n" +
                   "Assigned Ranger  : " + getAssignedRanger() + "\n" +
                   "Rescue Priority  : " + determinePriority() + "\n" +
                   "Current Status   : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost: " + formatMoney(calculateTotalCost());
        }
    }

    // SUBCLASS 3 - Endangered Species Rescue
   
    public static class EndangeredSpeciesRescue extends RescueCase {

        private String conservationClassification;
        private double securityCost;
        private boolean specialistTeamRequired;

        public EndangeredSpeciesRescue(String id, String name, String species,
                                       String location, String ranger,
                                       int days, double dailyCost, String status,
                                       String classification, double securityCost,
                                       boolean specialistTeamRequired) {
            super(id, name, species, location, ranger, days, dailyCost, status);
            this.conservationClassification = classification;
            this.securityCost = securityCost;
            this.specialistTeamRequired = specialistTeamRequired;
        }

        public String getConservationClassification() { return conservationClassification; }
        public void setConservationClassification(String v) { this.conservationClassification = v; }

        public double getSecurityCost() { return securityCost; }
        public void setSecurityCost(double v) { this.securityCost = v; }

        public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
        public void setSpecialistTeamRequired(boolean v) { this.specialistTeamRequired = v; }

        @Override
        public double calculateTotalCost() {
            double total = calculateBaseCost() + securityCost;
            if (specialistTeamRequired) total += 8000.00;
            return total;
        }

        @Override
        public String determinePriority() {
            boolean crit = "Critically Endangered".equalsIgnoreCase(conservationClassification);
            if (specialistTeamRequired && crit) return "Critical";
            if (specialistTeamRequired || crit) return "High";
            if ("Endangered".equalsIgnoreCase(conservationClassification)) return "Medium";
            return "Low";
        }

        @Override
        public String getRescueType() { return "Endangered Species Rescue"; }

        @Override
        public String displaySpecificInfo() {
            return "Conservation Class.      : " + conservationClassification + "\n" +
                   "Security Cost            : " + formatMoney(securityCost) + "\n" +
                   "Specialist Team Required : " + (specialistTeamRequired ? "Yes" : "No");
        }

        @Override public void startRescue()    { setCurrentRescueStatus("Rescue in Progress"); }
        @Override public void completeRescue() { setCurrentRescueStatus("Rescue Completed"); }

        @Override
        public String generateSummary() {
            return "Rescue Case ID   : " + getRescueCaseId() + "\n" +
                   "Rescue Type      : " + getRescueType() + "\n" +
                   "Species          : " + getSpecies() + "\n" +
                   "Assigned Ranger  : " + getAssignedRanger() + "\n" +
                   "Rescue Priority  : " + determinePriority() + "\n" +
                   "Current Status   : " + getCurrentRescueStatus() + "\n" +
                   "Total Rescue Cost: " + formatMoney(calculateTotalCost());
        }
    }

    
    // BUSINESS LOGIC - RescueManager (separate from UI, testable)
    
    public static class RescueManager {

        private final List<RescueCase> rescueCases = new ArrayList<>();

        public void addRescueCase(RescueCase rc) {
            if (rc == null) throw new IllegalArgumentException("Rescue case cannot be null.");
            String id = rc.getRescueCaseId();
            if (id == null || id.trim().isEmpty())
                throw new IllegalArgumentException("Rescue Case ID cannot be blank.");
            if (searchRescueCase(id) != null)
                throw new IllegalArgumentException("Rescue Case ID already exists: " + id);
            rescueCases.add(rc);
        }

        public RescueCase searchRescueCase(String id) {
            if (id == null) return null;
            for (RescueCase rc : rescueCases) {
                if (rc.getRescueCaseId().equalsIgnoreCase(id.trim())) return rc;
            }
            return null;
        }

        public boolean updateRescueStatus(String id, String newStatus) {
            RescueCase rc = searchRescueCase(id);
            if (rc == null) return false;
            rc.setCurrentRescueStatus(newStatus);
            return true;
        }

        public List<RescueCase> getAllRescueCases() { return rescueCases; }
        public int getTotalRescueCases()            { return rescueCases.size(); }

        public double getTotalRescueCost() {
            double total = 0;
            for (RescueCase rc : rescueCases) total += rc.calculateTotalCost();
            return total;
        }

        public boolean isDuplicateId(String id) { return searchRescueCase(id) != null; }
    }

    
    // USER INTERFACE - JOptionPane menu
   
    public static class RescueOperationsSystem {

        private static final RescueManager manager = new RescueManager();

        public static void main(String[] args) {
            boolean running = true;

            while (running) {
                String menu = "=======================================\n" +
                              "WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                              "=======================================\n" +
                              "1. Create Rescue Case\n" +
                              "2. Search Rescue Case\n" +
                              "3. Update Rescue Status\n" +
                              "4. Display All Rescue Cases\n" +
                              "5. Rescue Report\n" +
                              "6. Exit\n" +
                              "=======================================\n" +
                              "Select an option:";

                String choice = JOptionPane.showInputDialog(null, menu, "WildLife SA", JOptionPane.PLAIN_MESSAGE);
                if (choice == null) { running = false; continue; }
                choice = choice.trim();

                switch (choice) {
                    case "1": createRescueCase(); break;
                    case "2": searchRescueCase(); break;
                    case "3": updateRescueStatus(); break;
                    case "4": displayAllRescueCases(); break;
                    case "5": generateRescueReport(); break;
                    case "6":
                        running = false;
                        JOptionPane.showMessageDialog(null, "Exiting. Goodbye!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,
                            "Invalid menu selection. Enter 1-6.",
                            "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        // ---------- 1. CREATE ----------
        private static void createRescueCase() {
            String type = JOptionPane.showInputDialog(null,
                "Select rescue case type:\n1. Injured Animal\n2. Orphaned Animal\n3. Endangered Species",
                "Create Rescue Case", JOptionPane.PLAIN_MESSAGE);
            if (type == null) return;
            type = type.trim();
            if (!type.equals("1") && !type.equals("2") && !type.equals("3")) {
                JOptionPane.showMessageDialog(null, "Invalid rescue type.");
                return;
            }

            String id = promptNonBlank("Enter Rescue Case ID:");
            if (id == null) return;
            if (manager.isDuplicateId(id)) {
                JOptionPane.showMessageDialog(null, "Duplicate Rescue Case ID!");
                return;
            }
            String name    = promptNonBlank("Enter Animal Name:");              if (name == null) return;
            String species = promptNonBlank("Enter Species:");                  if (species == null) return;
            String loc     = promptNonBlank("Enter Rescue Location:");          if (loc == null) return;
            String ranger  = promptNonBlank("Enter Assigned Ranger:");          if (ranger == null) return;
            Integer days   = promptPositiveInt("Enter Number of Rescue Days:"); if (days == null) return;
            Double daily   = promptPositiveDouble("Enter Daily Care Cost (R):"); if (daily == null) return;

            RescueCase rc = null;
            try {
                if (type.equals("1")) {
                    String injury = promptNonBlank("Injury Description:"); if (injury == null) return;
                    Double vet    = promptNonNegativeDouble("Veterinary Treatment Cost (R):"); if (vet == null) return;
                    Boolean surg  = promptYesNo("Surgery Required?");
                    rc = new InjuredAnimalRescue(id, name, species, loc, ranger, days, daily,
                                                 "New Rescue", injury, vet, surg);
                } else if (type.equals("2")) {
                    Integer age    = promptPositiveInt("Estimated Age (Months):"); if (age == null) return;
                    Double feeding = promptNonNegativeDouble("Feeding Cost (R):"); if (feeding == null) return;
                    Boolean foster = promptYesNo("Foster Care Required?");
                    rc = new OrphanedAnimalRescue(id, name, species, loc, ranger, days, daily,
                                                  "New Rescue", age, feeding, foster);
                } else {
                    String cls      = promptNonBlank("Conservation Classification:"); if (cls == null) return;
                    Double security = promptNonNegativeDouble("Security Cost (R):"); if (security == null) return;
                    Boolean spec    = promptYesNo("Specialist Team Required?");
                    rc = new EndangeredSpeciesRescue(id, name, species, loc, ranger, days, daily,
                                                     "New Rescue", cls, security, spec);
                }
                manager.addRescueCase(rc);
                JOptionPane.showMessageDialog(null,
                    "Rescue case created!\n\n" + rc.generateSummary(),
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        // ---------- 2. SEARCH ----------
        private static void searchRescueCase() {
            String id = JOptionPane.showInputDialog("Enter Rescue Case ID to search:");
            if (id == null) return;
            RescueCase rc = manager.searchRescueCase(id);
            if (rc == null) {
                JOptionPane.showMessageDialog(null, "No case found with ID: " + id);
            } else {
                showTextDialog("Rescue Case Details", buildFullDetails(rc));
            }
        }

        // ---------- 3. UPDATE STATUS ----------
        private static void updateRescueStatus() {
            String id = JOptionPane.showInputDialog("Enter Rescue Case ID to update:");
            if (id == null) return;
            RescueCase rc = manager.searchRescueCase(id);
            if (rc == null) {
                JOptionPane.showMessageDialog(null, "No case found with ID: " + id);
                return;
            }
            String[] options = {"Rescue in Progress", "Rescue Completed", "Under Observation", "New Rescue"};
            String status = (String) JOptionPane.showInputDialog(null,
                "Select new status for " + rc.getRescueCaseId() + ":",
                "Update Status", JOptionPane.QUESTION_MESSAGE, null, options, rc.getCurrentRescueStatus());
            if (status == null) return;
            manager.updateRescueStatus(id, status);
            JOptionPane.showMessageDialog(null, "Updated.\n\n" + rc.generateSummary());
        }

        // ---------- 4. DISPLAY ALL ----------
        private static void displayAllRescueCases() {
            List<RescueCase> all = manager.getAllRescueCases();
            if (all.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No rescue cases yet.");
                return;
            }
            StringBuilder sb = new StringBuilder("ALL RESCUE CASES (" + all.size() + ")\n");
            sb.append("==================================================\n");
            for (RescueCase rc : all) {
                sb.append(buildFullDetails(rc)).append("\n");
                sb.append("--------------------------------------------------\n");
            }
            showTextDialog("All Rescue Cases", sb.toString());
        }

        // ---------- 5. REPORT ----------
        private static void generateRescueReport() {
            List<RescueCase> all = manager.getAllRescueCases();
            StringBuilder sb = new StringBuilder();
            sb.append("==================================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("==================================================\n");
            if (all.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (RescueCase rc : all) {
                    sb.append("Case ID          : ").append(rc.getRescueCaseId()).append("\n");
                    sb.append("Type             : ").append(rc.getRescueType()).append("\n");
                    sb.append("Species          : ").append(rc.getSpecies()).append("\n");
                    sb.append("Rescue Location  : ").append(rc.getRescueLocation()).append("\n");
                    sb.append("Assigned Ranger  : ").append(rc.getAssignedRanger()).append("\n");
                    sb.append("Priority         : ").append(rc.determinePriority()).append("\n");
                    sb.append("Status           : ").append(rc.getCurrentRescueStatus()).append("\n");
                    sb.append("Total Cost       : ").append(RescueCase.formatMoney(rc.calculateTotalCost())).append("\n");
                    sb.append("--------------------------------------------------\n");
                }
            }
            sb.append("==================================================\n");
            sb.append("Total Rescue Cases : ").append(manager.getTotalRescueCases()).append("\n");
            sb.append("Total Rescue Cost  : ").append(RescueCase.formatMoney(manager.getTotalRescueCost())).append("\n");
            sb.append("==================================================\n");
            showTextDialog("Wildlife Rescue Report", sb.toString());
        }

        // ---------- helpers ----------
        private static String buildFullDetails(RescueCase rc) {
            return "Rescue Case ID        : " + rc.getRescueCaseId() + "\n" +
                   "Animal Name           : " + rc.getAnimalName() + "\n" +
                   "Rescue Type           : " + rc.getRescueType() + "\n" +
                   "Species               : " + rc.getSpecies() + "\n" +
                   "Rescue Location       : " + rc.getRescueLocation() + "\n" +
                   "Assigned Ranger       : " + rc.getAssignedRanger() + "\n" +
                   "Number of Rescue Days : " + rc.getNumberOfRescueDays() + "\n" +
                   "Daily Care Cost       : " + RescueCase.formatMoney(rc.getDailyCareCost()) + "\n" +
                   "Current Status        : " + rc.getCurrentRescueStatus() + "\n" +
                   "Rescue Priority       : " + rc.determinePriority() + "\n" +
                   rc.displaySpecificInfo() + "\n" +
                   "Total Rescue Cost     : " + RescueCase.formatMoney(rc.calculateTotalCost()) + "\n";
        }

        private static void showTextDialog(String title, String content) {
            JTextArea area = new JTextArea(content);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        private static String promptNonBlank(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(msg);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                JOptionPane.showMessageDialog(null, "Cannot be blank.");
            }
        }

        private static Integer promptPositiveInt(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(msg);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    JOptionPane.showMessageDialog(null, "Must be greater than 0.");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Enter a whole number.");
                }
            }
        }

        private static Double promptPositiveDouble(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(msg);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    JOptionPane.showMessageDialog(null, "Must be greater than 0.");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Enter a number.");
                }
            }
        }

        private static Double promptNonNegativeDouble(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(msg);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    JOptionPane.showMessageDialog(null, "Cannot be negative.");
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Enter a number.");
                }
            }
        }

        private static Boolean promptYesNo(String msg) {
            int r = JOptionPane.showConfirmDialog(null, msg, "Yes / No", JOptionPane.YES_NO_OPTION);
            return r == JOptionPane.YES_OPTION;
        }
    }
}