package com.mycompany.prog6112_assignment_2;

import com.mycompany.prog6112_assignment_2.PROG6112_ASSIGNMENT_2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RescueManagerTest {

    private RescueManager manager;

    @BeforeEach
    public void setUp() {
        manager = new RescueManager();
    }

    @Test
    public void testInjuredWithoutSurgery() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR001", "Elephant", "African Elephant", "Kruger", "Ranger A",
            5, 100.00, "New Rescue", "Broken leg", 2000.00, false);
        assertEquals(2500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testInjuredWithSurgery() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR002", "Elephant", "African Elephant", "Kruger", "Ranger A",
            5, 100.00, "New Rescue", "Broken leg", 2000.00, true);
        assertEquals(7500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedWithoutFoster() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR003", "Baby Rhino", "White Rhino", "Hluhluwe", "Ranger B",
            10, 200.00, "New Rescue", 6, 1500.00, false);
        assertEquals(3500.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testOrphanedWithFoster() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR004", "Baby Rhino", "White Rhino", "Hluhluwe", "Ranger B",
            10, 200.00, "New Rescue", 6, 1500.00, true);
        assertEquals(6000.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testEndangeredWithoutSpecialist() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR005", "Pangolin", "Ground Pangolin", "Limpopo", "Ranger C",
            7, 300.00, "New Rescue", "Endangered", 4000.00, false);
        assertEquals(6100.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testEndangeredWithSpecialist() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR006", "Pangolin", "Ground Pangolin", "Limpopo", "Ranger C",
            7, 300.00, "New Rescue", "Critically Endangered", 4000.00, true);
        assertEquals(14100.00, r.calculateTotalCost(), 0.001);
    }

    @Test
    public void testInjuredPriorityCritical() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR007", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, "New Rescue", "Gunshot", 15000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testInjuredPriorityLow() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR008", "Lion", "African Lion", "Kgalagadi", "Ranger D",
            3, 500.00, "New Rescue", "Cut", 1000.00, false);
        assertEquals("Low", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityCritical() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR009", "Baby Elephant", "African Elephant", "Addo", "Ranger E",
            5, 400.00, "New Rescue", 2, 3000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testOrphanedPriorityLow() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR010", "Juvenile", "African Elephant", "Addo", "Ranger E",
            5, 400.00, "New Rescue", 18, 3000.00, false);
        assertEquals("Low", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityCritical() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR011", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, "New Rescue", "Critically Endangered", 9000.00, true);
        assertEquals("Critical", r.determinePriority());
    }

    @Test
    public void testEndangeredPriorityMedium() {
        EndangeredSpeciesRescue r = new EndangeredSpeciesRescue(
            "WR012", "Rhino", "Black Rhino", "Kruger", "Ranger F",
            6, 600.00, "New Rescue", "Endangered", 9000.00, false);
        assertEquals("Medium", r.determinePriority());
    }

    @Test
    public void testStartRescueUpdatesStatus() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR013", "Zebra", "Plains Zebra", "Etosha", "Ranger G",
            4, 150.00, "New Rescue", "Sprain", 1200.00, false);
        r.startRescue();
        assertEquals("Rescue in Progress", r.getCurrentRescueStatus());
    }

    @Test
    public void testCompleteRescueUpdatesStatus() {
        OrphanedAnimalRescue r = new OrphanedAnimalRescue(
            "WR014", "Baby Giraffe", "Giraffe", "Etosha", "Ranger G",
            4, 150.00, "New Rescue", 4, 800.00, false);
        r.completeRescue();
        assertEquals("Rescue Completed", r.getCurrentRescueStatus());
    }

    @Test
    public void testSearchExisting() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "WR015", "Leopard", "African Leopard", "Sabie", "Ranger H",
            2, 250.00, "New Rescue", "Snare", 3000.00, false);
        manager.addRescueCase(r);
        assertNotNull(manager.searchRescueCase("WR015"));
    }

    @Test
    public void testSearchNonExisting() {
        assertNull(manager.searchRescueCase("WR999"));
    }

    @Test
    public void testPreventDuplicate() {
        InjuredAnimalRescue r1 = new InjuredAnimalRescue(
            "WR016", "Buffalo", "African Buffalo", "Hluhluwe", "Ranger J",
            5, 180.00, "New Rescue", "Broken horn", 2500.00, false);
        manager.addRescueCase(r1);

        InjuredAnimalRescue r2 = new InjuredAnimalRescue(
            "WR016", "Buffalo", "African Buffalo", "Hluhluwe", "Ranger J",
            5, 180.00, "New Rescue", "Broken horn", 2500.00, false);

        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(r2));
    }

    @Test
    public void testBlankIdRejected() {
        InjuredAnimalRescue r = new InjuredAnimalRescue(
            "   ", "Bird", "Eagle", "Drakensberg", "Ranger L",
            2, 100.00, "New Rescue", "Wing", 500.00, false);
        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(r));
    }

    @Test
    public void testNullRescueCaseRejected() {
        assertThrows(IllegalArgumentException.class, () -> manager.addRescueCase(null));
    }

    @Test
    public void testTotalRescueCasesAndTotalCost() {
        InjuredAnimalRescue r1 = new InjuredAnimalRescue(
            "WR017", "Elephant", "African Elephant", "Kruger", "Ranger A",
            5, 100.00, "New Rescue", "Broken leg", 2000.00, false); // 2500

        OrphanedAnimalRescue r2 = new OrphanedAnimalRescue(
            "WR018", "Baby Rhino", "White Rhino", "Hluhluwe", "Ranger B",
            10, 200.00, "New Rescue", 6, 1500.00, true); // 6000

        manager.addRescueCase(r1);
        manager.addRescueCase(r2);

        assertEquals(2, manager.getTotalRescueCases());
        assertEquals(8500.00, manager.getTotalRescueCost(), 0.001);
    }
}